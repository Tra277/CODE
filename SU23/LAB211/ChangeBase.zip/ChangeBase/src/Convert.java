
public class Convert {

    public int OtherToDec(String Other, int base) {
        int result = 0;
        String HEX = "0123456789ABCDEF";
        Other = Other.toUpperCase();
        for(int i =0;i<Other.length();i++){
            result += HEX.indexOf(Other.charAt(i)) * Math.pow(base, Other.length()-1-i);
        }
        return result;
    }

    public String DecToOther(int Dec, int base) {
        String result="";
        String HEX = "0123456789ABCDEF";
        while (Dec>0) {            
            result=HEX.charAt(Dec%base)+result;
            Dec/=base;
        }
        return result;

    }
}
