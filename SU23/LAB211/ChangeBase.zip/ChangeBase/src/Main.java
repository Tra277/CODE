public class Main {
    
    public static void main(String[] args) {
        Validation validation = new Validation();
        Convert convert = new Convert();
        while (true) {            
            int inBase = validation.getBase("Enter Base Input: ");
            String value = validation.getValue("Enter Value input", inBase, "Value invalid");
            
            int outBase = validation.getBase("Enter Base Output");
            
            System.out.println("After change base: ");
            System.out.println("The output: ");
            
            if(inBase == 10){
                System.out.println(convert.DecToOther(Integer.parseInt(value), outBase));
            }else{
                int decTmp = convert.OtherToDec(value, inBase);
                System.out.println(convert.DecToOther(decTmp, outBase));
            }
            System.out.println("=======================================");
        }
    }

}
