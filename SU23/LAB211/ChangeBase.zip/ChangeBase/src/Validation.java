
import java.util.Scanner;

public class Validation {

    Scanner sc = new Scanner(System.in);

    public int getBase(String msg) {
        while (true) {
            try {
                System.out.println(msg);
                int base = Integer.parseInt(sc.nextLine().trim());
                if (base == 2 || base == 10 || base == 16) {
                    return base;
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println("You must input 2, 10 or 16");
            }
        }
    }

    public String getValue(String msg, int base,String err) {
        while (true) {
            try {
                System.out.println(msg);
                String value = sc.nextLine().trim();
                switch (base) {
                    case 2:
                        if (value.matches("[0-1]+")) {
                            return value;
                        }
                        break;
                    case 10:
                        if (value.matches("[0-9]+")) {
                            return value;
                        }
                        break;
                    case 16:
                        if (value.matches("[0-9a-fA-F]+")) {
                            return value;
                        }
                }
            } catch (Exception e) {
                e.printStackTrace(System.out);
            }
            System.out.println(err);
        }
    }
}
